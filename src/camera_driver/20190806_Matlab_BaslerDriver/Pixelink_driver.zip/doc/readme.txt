========================================================
    Matlab Interface for PixeLINK cameras (plFGI)
========================================================

		Directory Contents:	

This is the doc directory of the plFGI. It contains all
relevant documentation.

   The following files are in this directory:

Directories:
--------------
PixeLINK	- contains the technical and user
		  documentation of the PL-A6xx camera
		  series.

Documents:
--------------
plUTGuide.doc	- The technical and user's manual for
		  the plFGI program (MS Word format).
plUTGuide.pdf	- The technical and user's manual for
		  the plFGI program (Adobe PDF).
FGI_and_plFGI_Report.doc	- The report of this project (DOC).
FGI_and_plFGI_Report.pdf	- The report of this project (PDF).

Other Files:
--------------
readme.txt	- this file

============================================================
 Copyright (c) 2002  M.A.E.Bakker, L.I.Oei, Vladimir Smutny
============================================================
