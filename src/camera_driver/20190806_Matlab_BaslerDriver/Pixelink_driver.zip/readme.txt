=====================================================================
  Matlab Interface for PixeLINK cameras (plFGI)
=====================================================================

  Directories:

  bin	- DLL (mex) files compiled with PixeLINK SDK 3.1 for Matlab 6
  doc	- documentation
  src	- source code


=====================================================================
  Copyright (c) 2002-2003  Center for Machine Perception
    Czech Technical University
    Faculty of Electrical Engineering
    Department of Cybernetics
    Czech Republic, Prague

    M.A.E.Bakker, L.I.Oei, Vladimir Smutny
=====================================================================
  Contact: Vladimir Smutny, smutny@vision.felk.cvut.cz
=====================================================================