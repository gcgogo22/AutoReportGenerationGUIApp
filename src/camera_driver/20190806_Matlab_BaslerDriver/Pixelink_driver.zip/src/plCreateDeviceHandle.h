/************************************************************************/
/* Filename:	plCreateDeviceHandle.h									*/
/* Description: Header file for plCreateDeviceHandle.cpp				*/
/* Authors:		L.I.Oei, M.A.E.Bakker									*/
/* Date:		2002/07/31												*/
/* Updates:																*/
/************************************************************************/
/* Header file for plCreateDeviceHandle.cpp.							*/
/************************************************************************/

void plCreateDeviceHandle(mxArray *returnArray[], U32 serialNumber);