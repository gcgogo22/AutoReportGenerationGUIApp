/************************************************************************/
/* Filename:	plError.h												*/
/* Description: Header file for plError.cpp								*/
/* Authors:		L.I.Oei, M.A.E.Bakker									*/
/* Date:		2002/08/06												*/
/* Updates:																*/
/************************************************************************/

int plError(PXL_RETURN_CODE, char*);