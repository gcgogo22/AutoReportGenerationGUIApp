/************************************************************************/
/* Filename:	plGetValue.h											*/
/* Description: Header file for plGetValue.cpp							*/
/* Authors:		L.I.Oei, M.A.E.Bakker									*/
/* Date:		2002/08/06												*/
/* Updates:																*/
/************************************************************************/

void plGetValue(mxArray *returnArray[], U32 serialNumber, char* parametername);