/************************************************************************/
/* Filename:	plPrintPossibleValues.h									*/
/* Description: Header file for plPrintPossibleValues.cpp				*/
/* Authors:		L.I.Oei, M.A.E.Bakker									*/
/* Date:		2002/08/06												*/
/* Updates:																*/
/************************************************************************/

void plPrintPossibleValues(char* parametername);