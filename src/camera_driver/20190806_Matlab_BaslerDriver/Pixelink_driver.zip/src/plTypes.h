/************************************************************************/
/* Filename:	plTypes.h												*/
/* Description: Header file containing (type) definitions.				*/
/* Authors:		M.A.E.Bakker, L.I.Oei									*/
/* Date:		2002/08/06												*/
/* Updates:																*/
/************************************************************************/

#define RAW	0x0
#define IMAGE 0x1
#define RGB24 0x2