/*=================================================================
 *
 * New OCVGRAB version
 *
 * CHECK FOR PROPER MATLAB INCLUDE / LIB PATH SETTINGS
 * 
 *=================================================================*/
/* $Revision: 0.00 $ */
#include "mex.h"

#include "cv.h"
#include "highgui.h"

#include <stdio.h>
#include <windows.h>
#include <process.h>

#ifdef R14 // 'R14 - hack'
typedef int mwSize;
#endif

// ok i see it's looking like spaghetti-code, who wanna make some objects?
static unsigned LowRes = false;
static unsigned Preview = false;
static unsigned Synchron = false;
static unsigned CamN = 0;
static unsigned CamID[] = {0,0,0,0,0,0,0,0};
static unsigned Index[] = {0,1,2,3,4,5,6,7};
static unsigned ExitCam[]={0,0,0,0,0,0,0,0};  
static HANDLE ImgReady[]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
static HANDLE CriticalSection[]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
static HANDLE hThread[]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
static unsigned threadID[]={0,0,0,0,0,0,0,0};

// pointer to image-arrays in workspace and OpenCV
mxArray* mImage[] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
IplImage* image[] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
struct DIM { 
	int dims[3];
} DIMS[]={{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0}};

/* function closes/destroys all threads, windows and arrays...*/
static void CloseStream(void)
{
	for (unsigned i=0; i<CamN; i++) {
		if (hThread[i]) {
			mexPrintf("Closing CamID %d ...\n",CamID[i]);mexEvalString("disp('');");
			ExitCam[i] = 1;
			WaitForSingleObject( hThread[i], 5000 );
			CloseHandle(CriticalSection[i]);
			CloseHandle(ImgReady[i]);
			hThread[i] = NULL;
			threadID[i] = 0;
		}
		mxDestroyArray(mImage[i]);
		mImage[i] = NULL;
	}
}

/*This is one streaming thread prototype - it should not try to communicate with 
 *MATLAB at all. This includes the use of mexPrintf, which attempts to print to 
 *the MATLAB command window. */
unsigned __stdcall OpenStream( void* pArguments ) {
    
	unsigned i = *((unsigned *)pArguments);

	ExitCam[i] = 0;

	CvCapture* capture = cvCaptureFromCAM(CamID[i]);

	if (capture) {

		char title[3];
		_itoa_s(CamID[i],title,3,10);
		if (Preview) cvNamedWindow( title, CV_WINDOW_AUTOSIZE );

		CvSize frsi;
		if (LowRes) {
			frsi.height = 240;
			frsi.width = 320;
		} else {
			frsi.height = 480;
			frsi.width = 640;
		}

		cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH, frsi.width);
		cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, frsi.height);
		cvSetCaptureProperty(capture, CV_CAP_PROP_FPS, 30);

		IplImage *frame = cvQueryFrame( capture );

		if (frame) {
			frsi.width = frame->height;
			frsi.height = frame->width;
	
			/* Set Dimension for array */
			DIMS[i].dims[0] = frsi.width;
			DIMS[i].dims[1] = frsi.height;
			DIMS[i].dims[2] = 3;

			/* allocate the buffers */
			image[i] = cvCreateImage( frsi, 8, 3 );

			while ( !ExitCam[i] && frame && image[i] ) {

				if (Preview) {
					cvShowImage( title, frame);
					cvWaitKey(1);
				}

				if (WaitForSingleObject(CriticalSection[i],50)==WAIT_OBJECT_0) {

					// bring into normal matlab orientation
					cvTranspose(frame,image[i]);
					// do some opencv-stuff here

					ReleaseSemaphore(ImgReady[i], 1, NULL);
					ReleaseSemaphore(CriticalSection[i],1,NULL);
				}

				frame = cvQueryFrame( capture );

			}

			cvReleaseImage(&image[i]);

		}

		cvReleaseCapture(&capture);

		if (Preview) cvDestroyWindow( title );

	}

	ExitCam[i] = 1;

    _endthreadex( 0 );
    return 0;
}

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{ 

		/* Check for proper number of arguments */
		if (nrhs==0)
			mexErrMsgTxt("at least one camera identifier necessary e.g. ocvgrab(0)"); 
		if ((nrhs>0)&&!mxIsDouble(prhs[0]))
			mexErrMsgTxt("camera identifier is double type vector e.g. ocvgrab([0 1])"); 
		if ((nrhs>1)&&!mxIsDouble(prhs[1]))
			mexErrMsgTxt("camera lowres switch is double type e.g. ocvgrab([0 1],1)"); 
		if ((nrhs>2)&&!mxIsDouble(prhs[2]))
			mexErrMsgTxt("camera preview switch is double type e.g. ocvgrab([0 1],0,1)"); 
		if ((nrhs>3)&&!mxIsDouble(prhs[3]))
			mexErrMsgTxt("camera synchron switch is double type e.g. ocvgrab([0 1],0,0,1)"); 
		unsigned N = min(max((unsigned)mxGetNumberOfElements(prhs[0]),1),8);
		double *cams = (double *)mxGetPr(prhs[0]);

		bool Change = (CamN!=N);
		for (unsigned i=0; i<N; i++) Change |= (CamID[i]!=(unsigned)*(cams+i));
		if (nrhs>1) Change |= (LowRes!=(unsigned)mxGetScalar(prhs[1]));
		if (nrhs>2) Change |= (Preview!=(unsigned)mxGetScalar(prhs[2]));
		if (nrhs>3) Synchron = (unsigned)mxGetScalar(prhs[3]);

		/* if first start or something is changed - restart all... */
		if ( Change ) { 

			if (CamN>0) mexPrintf("Configuration changed...\n"); mexEvalString("disp('');");
			CloseStream(); 

			if (nrhs>1) LowRes=(unsigned)mxGetScalar(prhs[1]);
			if (nrhs>2) Preview=(unsigned)mxGetScalar(prhs[2]);
			CamN = N;
			nlhs = N;
			for (unsigned i=0; i<CamN; i++) CamID[i]=(unsigned)*(cams+i);
			Change = false;

			/* make a short initialization of first cam to "wake up" all available cams */
			CvCapture* capture = cvCaptureFromCAM(0);
			IplImage *frame = cvQueryFrame( capture );
			cvReleaseCapture(&capture);

			/* Create Camera Threads and wait for the first images to be initialized */
			for (unsigned i=0; i<CamN; i++) {

				for (unsigned j=0; j<CamN; j++) 
					if ((i!=j)&&(CamID[i]==CamID[j])) mexErrMsgTxt("same index used twice...");

				mexPrintf("Connecting CamID %d ...\n",CamID[i]);mexEvalString("disp('');");
				CriticalSection[i] = CreateSemaphore( NULL, 1, 1, NULL);
				ImgReady[i] = CreateSemaphore( NULL, 0, 1, NULL);
				hThread[i] = (HANDLE)_beginthreadex( NULL, 0, &OpenStream, &Index[i], 0, &threadID[i] );
				if ( WaitForSingleObject( ImgReady[i],2000)==WAIT_TIMEOUT ) {
					mexPrintf("CamID %d not ready...\n",CamID[i]);mexEvalString("disp('');");
					CloseStream(); // if something went wrong - stop the threads
				} else ReleaseSemaphore(ImgReady[i], 1, NULL);

				mImage[i] = mxCreateNumericArray(3,(const mwSize*)DIMS[i].dims, mxUINT8_CLASS, mxREAL); 
				mexMakeArrayPersistent(mImage[i]);
				if (!mImage[i]) mexErrMsgTxt("not able to create array in workspace...");
				plhs[i] = mImage[i];

			}
		}

		for (unsigned i=0; i<CamN; i++) {

			if (Synchron) WaitForSingleObject(ImgReady[i],50);

			/* Copy image to matlab + reorganize from pixelwise BGR to planewise RRR GGG BBB */
			if ( image[i] && mImage[i] && (WaitForSingleObject(CriticalSection[i],50)==WAIT_OBJECT_0)) {
				
				unsigned img_1 = DIMS[i].dims[0]*DIMS[i].dims[1];
				unsigned img_2 = img_1*2;
				char* img = image[i]->imageData;
				char* pImage = (char*)mxGetPr(mImage[i]);
				for (unsigned j=0; j < img_1; j++) {
					*(pImage+img_2) =*(img++); // B
					*(pImage+img_1) = *(img++); // G
					*(pImage++)	   = *(img++); // R 
				}

				ReleaseSemaphore(CriticalSection[i], 1,NULL);

			}

		}
        
        mexAtExit(CloseStream);

        return;
}