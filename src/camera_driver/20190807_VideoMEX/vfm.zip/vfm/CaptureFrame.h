

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CaptureFrame.h: interface for the CCaptureFrame class.
// This declares the main windowing class
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour
//	Revision
//		1998/12/16
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


#if !defined(AFX_CAPTUREFRAME_H__F18B4981_8D16_11D2_B14B_0000B482A708__INCLUDED_)
#define AFX_CAPTUREFRAME_H__F18B4981_8D16_11D2_B14B_0000B482A708__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/*
#define MENUITEM_HANDLER(menuid, func) \
	if(uMsg == WM_COMMAND && id == LOWORD(wParam) && code == HIWORD(wParam)) \
	{ \
		bHandled = TRUE; \
		lResult = func(HIWORD(wParam), LOWORD(wParam), (HWND)lParam, bHandled); \
		if(bHandled) \
			return TRUE; \
	}
*/
#include <vfw.h>
#include <string>
#include "resource.h"
#include "menuitem.h"
#include "ImgBuffer.h"

/*
 * A WM_COMMAND message by definition, has a notification type stored in 
 * in the hi-word of wParam. This is either 0 or 1 depending on its source
 * We define an extra notification, indicating that command is to be treated
 * as a request for an update on the menu item.
 */
#define CN_COMMAND_UI ((WORD)2)					// used by this framework to request an update
												// on the UI item
										

/*
 * To enable menu item updating, the following macro _must_ be inserted in
 * the ATL message map.
 * Also note that the OnInitMenuPopup function must also be declared
 * Given time, this will be moved into a parent class.
 */
#define ON_WM_INITMENUPOPUP() \
	if (uMsg == WM_INITMENUPOPUP) {\
		lResult = OnInitMenuPopup (wParam, lParam); \
	}

/*
 * UPDATE_MENUITEM(id, function)
 * This declares a message map entry for updating a menu item
 * This relies upon the CMenuItem class. Again, alot of this functionality
 * will be moved into a parent class
 */
#define UPDATE_MENUITEM(id, function) \
	if (uMsg == WM_COMMAND && CN_COMMAND_UI == HIWORD(wParam) && id == LOWORD(wParam)) { \
		bHandled = TRUE; \
		function((CMenuItem*)lParam); \
		lResult = 0; \
	}



/*
 * COMMAND_HANDLER2(id, func)
 * A simplified command handler, which allows all proper notification codes
 * through to the handler.
 */
#define COMMAND_HANDLER2(id, func) \
	if(uMsg == WM_COMMAND && HIWORD(wParam) <= 1 && id == LOWORD(wParam)) \
	{ \
		bHandled = TRUE; \
		func(); \
		lResult = 0; \
	}


/*
 * RANGE_HANDLER(id1, id2, func)
 * A simplified command handler, which allows all proper notification codes
 * through to the handler.
 */
#define RANGE_HANDLER(id1, id2, func) \
	if(uMsg == WM_COMMAND && HIWORD(wParam) <= 1 && \
		id1 <= LOWORD(wParam) && id2 >= LOWORD(wParam)) \
	{ \
		bHandled = TRUE; \
		func(LOWORD(wParam)); \
		lResult = 0; \
	}






class CCaptureFrame : public CWindowImpl <CCaptureFrame>  
{

public: // CWindowImpl managment code
	static CWndClassInfo& GetWndClassInfo(); 

	BEGIN_MSG_MAP(CCaptureFrame)
		ON_WM_INITMENUPOPUP	()
		UPDATE_MENUITEM		(ID_WINDOWMENU_PREVIEW,	OnUpdatePreview)
		UPDATE_MENUITEM		(ID_WINDOWMENU_STRETCH,	OnUpdateStretch)
		UPDATE_MENUITEM		(ID_CONFIGMENU_FORMAT,	OnUpdateFormatDlg)
		UPDATE_MENUITEM		(ID_CONFIGMENU_SOURCE,	OnUpdateSourceDlg)
		UPDATE_MENUITEM		(ID_CONFIGMENU_DISPLAY,	OnUpdateDisplayDlg)
		RANGE_HANDLER		(ID_DEVICEMENU_0, ID_DEVICEMENU_9, OnSelectDriver)
		COMMAND_HANDLER2	(ID_WINDOWMENU_PREVIEW, OnPreview)
		COMMAND_HANDLER2	(ID_WINDOWMENU_STRETCH, OnStretch)
		COMMAND_HANDLER2	(ID_WINDOWMENU_RESET,	ResetSize)
		COMMAND_HANDLER2	(ID_CONFIGMENU_FORMAT,	ConfigureFormat)
		COMMAND_HANDLER2	(ID_CONFIGMENU_SOURCE,	ConfigureSource)
		COMMAND_HANDLER2	(ID_CONFIGMENU_DISPLAY,	ConfigureDisplay)
		COMMAND_HANDLER2	(ID_WINDOWMENU_HIDE,	OnHide)
		MESSAGE_HANDLER		(WM_SIZE,				OnSize);
	END_MSG_MAP()

	CCaptureFrame();
	virtual ~CCaptureFrame();

public:
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Grab
	// Cleans up the internal frame queue and captures wCount
	// frames, returning when complete.
	// The function throws a STL string pointer if an error occurs
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void Grab (WORD wCount = 1);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Create
	// Creates the window and creates the VFW capture window
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	HWND Create (HWND hWndParent, RECT & rcPos, LPCTSTR sszWindowName = NULL, DWORD dwStyle = WS_CHILD | WS_VISIBLE, DWORD dwExStyle = 0, UINT nID = 0);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// ConnectDevice
	// Connects to a particular device
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool	ConnectDevice (WORD index);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// SetPreview
	// Switches the preview functionality on or off
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool	SetPreview (bool bPreview = true);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// SetStretch
	// Switches the stretching of the preview screen on or off.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool	SetStretch (bool bStretch = true);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// GetMatlabArrays
	//		Converts the buffer given the lower and upper bounds
	//		to matlab arrays.
	// Arguments
	//	lower		Zero based index into array describing the lower 
	//				bound of the conversion. Auto bound by range buffer
	//
	//	upper		Zero based index into array. As above but for upper 
	//				bound. Auto bound by buffer range, _except_ that
	//				values less than zero indicate the last element of the
	//				the array.
	//
	//	plhs		An array of Matlab array pointers to store the result
	//
	//	nlhs		Number of elements in plhs. In accordance with Matlab's
	//				tradition the minimum value is one. (ie 0 ==> 1)
	//	
	//	Result
	//		returns if all okay, else throws a std::string pointer

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void GetMatlabArrays (int lower, int upper, 
						  mxArray *plhs[], int nlhs);


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// ConfigureSource ConfigureFormat ConfigureDisplay
	//	These functions attempt to invoke their respective VFW dialogs
	//	If succesful, they return true, else false.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool ConfigureSource ();
	bool ConfigureFormat();
	bool ConfigureDisplay();

	void OnHide ();
	void OnShow ();
	void OnShow (bool bShow);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// ResetSize
	// Called by the framework to reset the size of the window
	// to the size of the video frame
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void ResetSize ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// GetDriverList
	// Returns a pointer to an array of (std) strings
	// The pointer together with the contents of the strings belongs
	// to this object and _must_ not be tampered with.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	std::string *GetDriverList ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// SetDriver
	// Loads the driver indicated by dwId
	// dwId must be in the range 0 - 9
	// return true iff successful
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool SetDriver (DWORD dwId);
protected:

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnInitMenuPopup
	//	Required by this framework to handle menu updates
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	LRESULT OnInitMenuPopup (WPARAM wParam, LPARAM lParam);


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnUpdateFormatDlg
	//	Called before the "Format Dlg" item in the Configure menu is 
	//	updated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnUpdateFormatDlg (CMenuItem *pItem);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnUpdateSourceDlg
	//	Called before the "Source Dlg" item in the Configure menu is 
	//	updated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnUpdateSourceDlg (CMenuItem *pItem);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnUpdateDisplayDlg
	//	Called before the "Display Dlg" item in the Configure menu is 
	//	updated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnUpdateDisplayDlg (CMenuItem *pItem);



	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnUpdatePreview
	// Called before the Preview Item in the Window menu is updated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnUpdatePreview (CMenuItem *pItem);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnPreview
	// Called when the Preview item in the Window menu is activated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnPreview		();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnUpdateStretch
	// Called before the Stretch Item in the Window menu is updated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnUpdateStretch (CMenuItem *pItem);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnStretch
	// Called when the Stretch item in the Window menu is activated
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnStretch		();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnSelectDriver
	// Called when a driver is selected from the drivers list
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	OnSelectDriver	(DWORD dwId);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// UpdateDeviceMenu
	// Called by the framework to update the contents
	// of the device menu.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	UpdateDeviceMenu(HMENU hMenu);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// BuildDeviceList
	// Rebuilds the device list
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	BuildDeviceList ();
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// EmptyDeviceList 
	// Clears the contents of the device list
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	EmptyDeviceList ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// OnSize
	// Called when window is resized.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// DeleteFormat
	// Delete an existing video format
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void DeleteFormat ();


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// RetrieveFormat
	// Gets the video format for the device.
	// Stored in m_pFormat variable
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void RetrieveFormat ();


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// SetFrameCallback
	// Called when about to process or complete a capture
	// Enables the callback from VFW to the program to inform of
	// a new frame
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void SetFrameCallback (bool bSet);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// ReleaseIC 
	// Releases any reference to the image compressor
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void ReleaseIC ();

protected:
	CAPDRIVERCAPS		m_vcaps;		// device capapbility
	HWND				m_hVfwWnd;		// capture window handle
	std::string			m_sDevices[10];	// array of devices by name
	bool				m_bPreview;		// true iff previewing
	bool				m_bStretch;		// true iff stretching 
	bool				m_bProportional;// true iff stretching is to maintain aspect ratio
	LPBITMAPINFO		m_pFormat;		// Pointer to the video format
	CFrameQueue			m_queue;
	HIC					m_hIC;			// Pointer to the current image compressor
	WORD				m_dwFrames;		// Number of frames left to grab

protected:	// static data
	static CCaptureFrame	*	m_pFrame;		// Stores a pointer to the current object capturing

protected: // static methods
	void SetSize ();
	static LRESULT PASCAL FrameCallback (HWND hWnd, LPVIDEOHDR lpVHdr);
};



#endif // !defined(AFX_CAPTUREFRAME_H__F18B4981_8D16_11D2_B14B_0000B482A708__INCLUDED_)
