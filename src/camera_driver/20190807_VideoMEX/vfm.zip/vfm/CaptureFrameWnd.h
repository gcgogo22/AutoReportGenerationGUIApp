
#ifndef __CAPTUREFRAMEWND__
#define __CAPTUREFRAMEWND__


#include <atlwin.h>
class CCaptureFrameWnd : public CWindowImpl<CCaptureFrameWnd>
{

	BEGIN_MSG_MAP(CCaptureFrameWnd)

	END_MSG_MAP
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// GetWndClassInfo
	// Overrides the static function for describing the functionality 
	// of this window, menus and all!!
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	static CWndClassInfo& GetWndClassInfo();
};

#endif
