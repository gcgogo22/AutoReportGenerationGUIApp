//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// ImgBuffer.cpp
//	Implements the classes required for the management of the 
//	images.
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour
//	Revision
//		1998/12/03
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#include <strstream>
#include "ImgBuffer.h"
#include "utility.h"
#include "memory.h"

#ifdef R14 // R14 - 'hack'
typedef int mwSize;
#endif

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CRawFrame Implementation
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
CRawFrame::CRawFrame (LPBITMAPINFO pInfo, LPBYTE pData):
	m_hDib (NULL),
	m_pData (NULL),
	m_pInInfo (pInfo)
{
	DWORD size = pInfo->bmiHeader.biSizeImage;
	if (size == 0)
		size = pInfo->bmiHeader.biHeight * pInfo->bmiHeader.biWidth * pInfo->bmiHeader.biBitCount;
	if (size != 0) {
		m_pData = new BYTE[size];
		memcpy (m_pData, pData, size);
	}
}


CRawFrame::~CRawFrame ()
{
	delete_array (m_pData);
	ClearDIB();
}


void CRawFrame::ClearDIB() {
	if (m_hDib != NULL) {
		GlobalFree(m_hDib);
		m_hDib = NULL;
	}
}



void CRawFrame::GetMatlabArray (HIC &hIC, unsigned char *pImage)
{
	// if the dib has not been decompressed then do it.
	if (m_hDib == NULL)
		Decompress (hIC);

	// if we still don't have a dib then return null
	if (m_hDib == NULL) return;

	register DWORD height;
	register DWORD width;

	// lock the dib in process memory and read its format
	LPBITMAPINFO lpNewDIB = (LPBITMAPINFO)GlobalLock (m_hDib);
	LPBITMAPINFOHEADER lpHeader= & (lpNewDIB->bmiHeader);

	height = Abs (lpHeader->biHeight);
	width = Abs (lpHeader->biWidth);

	DWORD size		= lpHeader->biSize; // size of the header structure
	DWORD imagearea = height * width;	// number of pixels
	
	// we are going to be reversing the picture as we place it into the
	// matlab array.

	// compute the entry point of the three color components
	// in the matlab array, so we begin transfer of first
	// raster line to the last matlab image column.

	unsigned char *pRed= pImage;
	pRed += height - 1;
	unsigned char *pGreen = pRed + imagearea;
	unsigned char *pBlue = pGreen + imagearea;

	// find the entry point of the bitmap i
	unsigned char *ptr = ((unsigned char *)(lpHeader)) + size;

	for (DWORD y = 0; y < height; y++) {
		for (DWORD x = 0; x < width; x++) {
			*pBlue = *ptr++;
			*pGreen = *ptr++;
			*pRed = *ptr++;
			pRed += height;
			pGreen += height;
			pBlue += height;
		}
		pRed -= imagearea;
		pGreen -= imagearea;
		pBlue -= imagearea;
		pRed--;
		pGreen--;
		pBlue--;
	}

	GlobalUnlock (m_hDib);
}


void	CRawFrame::Decompress (HIC &hIC)
{
	BITMAPINFO nbmi					= *	m_pInInfo;
	nbmi.bmiHeader.biPlanes			=	1;
	nbmi.bmiHeader.biBitCount		=	24;
	nbmi.bmiHeader.biCompression	=	BI_RGB;
	nbmi.bmiHeader.biSizeImage		=	m_pInInfo->bmiHeader.biWidth  * 
										m_pInInfo->bmiHeader.biHeight * 
										sizeof(unsigned long);
	nbmi.bmiHeader.biClrUsed		=	0;
	nbmi.bmiHeader.biClrImportant	=	0;

	
	if (hIC == NULL)
	{
		hIC = ICLocate (ICTYPE_VIDEO, NULL, &(m_pInInfo->bmiHeader), 
							 &(nbmi.bmiHeader), ICMODE_DECOMPRESS);
		if (hIC == NULL) return;
	}


	// Note that the Compressor now belongs to the callers.
	ClearDIB ();
	m_hDib= ICImageDecompress (hIC, 0, m_pInInfo, m_pData, &nbmi);
}



void	CRawFrame::GetDimensions (LONG *pWidth, LONG *pHeight)
{
	LPBITMAPINFOHEADER lpHeader= & (m_pInInfo->bmiHeader);
	*pWidth = Abs (lpHeader->biWidth);
	*pHeight = Abs (lpHeader->biHeight);
}


//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CFrameQueue Implementation
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
CFrameQueue::CFrameQueue (DWORD size)
:	m_size(0),
	m_next(0),
	m_buffer(NULL)
{
	SetSize(size);
}

CFrameQueue::~CFrameQueue ()
{
	FreeBuffer();
}

void CFrameQueue::AppendFrame (LPBITMAPINFO pInfo, LPBYTE pData)
{
	if (m_buffer == NULL) return;
	if (m_buffer[m_next] != NULL) 
		delete m_buffer[m_next];
	m_buffer[m_next] = new CRawFrame(pInfo, pData);
	if (++m_next >= m_size) 
		m_next = 0;
}




void CFrameQueue::GetMatlabArrays (	int lower,			int upper, 
									mxArray *plhs[],	int nlhs,
									HIC &hIC)
{
	std::ostrstream		error;
	std::string		*	pFinal = NULL;

	if (nlhs == 1) {
		plhs[0] = GetImageArray (lower, upper, hIC);
	}

	return;
}





void CFrameQueue::FreeBuffer ()
{
	if (m_buffer != NULL) {
		ClearBuffer();
		delete m_buffer;
		m_buffer = NULL;
		m_size = 0;
	}
}


bool CFrameQueue::SetSize (DWORD size)
{
	if (size == m_size) return true;
	if (size == 0) return false;
	FreeBuffer();
	m_buffer = new PRawFrame[size];
	for (int i = 0; i < size; i++)
		m_buffer[i] = NULL;
	m_size = size;
	return true;
}


void CFrameQueue::ClearBuffer ()
{
	if (m_buffer == NULL) return;
	for (DWORD i = 0; i < m_size; i++) {
		if (m_buffer[i] != NULL) {
			delete m_buffer[i];
			m_buffer[i] = NULL;
		}
	}
	m_next = 0;
}

mxArray* CFrameQueue::GetImageArray(int lower, int upper, HIC & hIC)
{
	// trim the range
	if (lower < 0)
		lower = 0;
	else if (lower >= m_size)
		lower = m_size - 1;
	if (upper < 0 || upper >= m_size)
		upper = m_size - 1;

	// now we scan to see if we have all the required images
	// and if not modify the range accordingly

	int arrayIndex;
	int index;
	int count;

	for (index = lower; index <= upper && m_buffer[index] != NULL; index++);
	if (index == lower) return NULL;
	if (index < upper)
		upper = index;
	
	int total = upper - lower + 1;
	// an array to store the dimensions of the matlab array
	// height width depth
	//
	int cArraySize[] = {0, 0, 3, total};
	m_buffer[lower]->GetDimensions ((LONG*)cArraySize+1, (LONG*)cArraySize);
	int framebytes = cArraySize[0] * cArraySize[1] * 3;

	mxArray *pResult = mxCreateNumericArray (4, (const mwSize*)cArraySize, mxUINT8_CLASS, mxREAL);
	unsigned char * pImages = (unsigned char*)mxGetPr(pResult);

	for (count=0, index = lower; 
		index <= upper && m_buffer[index] != NULL; 
		count++, index++)
	{
		arrayIndex = mxCalcSingleSubscript (pResult, 1, (const mwSize*)&count);
		m_buffer[index]->GetMatlabArray (hIC, pImages + (framebytes * count));
	}

	return pResult;
}
