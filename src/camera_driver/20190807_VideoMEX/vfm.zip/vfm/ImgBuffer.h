

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//	ImgBuffer.h
//		This file declares the image classes responsible
//		for storing and decompressing a buffer of raw images.
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour
//	Revision
//		1998/12/16
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


#ifndef __CRAWFRAME__
#define __CRAWFRAME__

#include <windows.h>
#include <vfw.h>
#include <string>
#include "mex.h"




//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CRawFrame
// This class encapsulates the core functionality
// of 
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
class CRawFrame {
public:
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Constructor 
	//	Initialises the object with the raw data, decompression is 
	//	not performed here.
	// Arguments:
	//	pInfo	pointer to the BITMAPINFO that describes the raw format
	//	pData	pointer to the raw data
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	CRawFrame (LPBITMAPINFO pInfo, LPBYTE pData);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Destructor
	//	Ensures that all the resources are freed
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	~CRawFrame ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// GetMatlabArray
	//	Decompresses the image in to the array pointed to by pImage
	// Arguments:
	//	hIC		Pointer to the image compressor. If null, an IC is 
	//			found automatically.
	//	pImage	Pointer to array of bytes, 3 per pixel.
	//			
	// Result:
	//	array.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void GetMatlabArray (HIC &hIC, unsigned char *pImage);
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// GetDimensions
	// Reads the dimensions of this image
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	GetDimensions (LONG *pWidth, LONG *pHeight);

protected: // methods
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// ClearDIB
	// Ensures that the internal device independant bitmap is 
	// unlocked and freed.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	ClearDIB ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Decompress
	//	Decompresses the image -
	// Pre:
	//	Image not decompressed - don't call otherwise
	// Arguments
	//	hIC		handle to a suggested image compressor codec
	//			if NULL, one is found automatically
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void	Decompress (HIC &hIC);

protected: // properties
	LPBITMAPINFO	m_pInInfo;	// Pointer to the descriptor for the raw image
								// This pointer does _not_belong to the class and
								// is passed only to 
	LPBYTE			m_pData;	// Pointer to the data
	HANDLE			m_hDib;		// The uncompressed image goes here
};



typedef CRawFrame * PRawFrame;

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CFrameQueue
//	Class implementing a circular queue of raw frames with
//	the facility for decompressing a range of frames to 
//	an array of matlab arrays.
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
class CFrameQueue
{
public:
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Constructor
	//	Initialises the buffer
	// Arguments
	//	size	The initial size of the buffer - defaults to one.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	CFrameQueue (DWORD size = 1);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Destructor
	//	Releases all stored frames
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	~CFrameQueue ();

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// SetSize
	//	Frees all frames and resizes the buffer.
	// Arguments	
	//	size		The new size of the buffer.
	// Result
	//	Returns true iff successful.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	bool SetSize (DWORD size);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// AppendFrame
	//	Places the frame in the next available slot in the queue
	//	If that slot is occupied, then the replaced frame is discarded
	//	(and the resources deallocated).
	// Arguments
	//	pInfo	Pointer to the image format data.
	//			Note that this, for the time being must be static 
	//			for the lifetime of this frame.
	//	pData	Pointer to the raw data.
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void AppendFrame (LPBITMAPINFO pInfo, LPBYTE pData);


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	//	GetMatlabArrays 
	//		Converts the buffer given the lower and upper bounds
	//		to matlab arrays.
	// Arguments
	//	lower		Zero based index into array describing the lower 
	//				bound of the conversion. Auto bound by range buffer
	//
	//	upper		Zero based index into array. As above but for upper 
	//				bound. Auto bound by buffer range, _except_ that
	//				values less than zero indicate the last element of the
	//				the array.
	//
	//	plhs		An array of Matlab array pointers to store the result
	//
	//	nlhs		Number of elements in plhs. In accordance with Matlab's
	//				tradition the minimum value is one. (ie 0 ==> 1)
	//	
	//	hIC			Optional handle to a Image Compression Codec
	//	Result
	//		returns if all okay, else throws a std::string pointer
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void GetMatlabArrays (int lower, int upper, 
								  mxArray *plhs[], int nlhs, 
								  HIC &hIC);

	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	//	ClearBuffer
	//		Removes all frames from the buffer
	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	void ClearBuffer ();

protected: // methods
	void	FreeBuffer ();
	
protected: // properties
	mxArray* GetImageArray (int lower, int upper, HIC &hIC);
	CRawFrame	**	m_buffer;		// array of frame pointers
	DWORD			m_size;			// size of array
	DWORD			m_next;			// pointer to the next element
};


#endif //__CRAWFRAME__