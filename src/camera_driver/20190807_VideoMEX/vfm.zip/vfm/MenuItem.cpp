//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// MenuItem.cpp
//	Implementation of the CMenuItem class.
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour
//	Revision
//		1998/12/16
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#include "stdafx.h"
#include "MenuItem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMenuItem::CMenuItem()
{

}

CMenuItem::~CMenuItem()
{

}


void CMenuItem::Enable(BOOL bOn)
{
	UINT flags;
	flags = MF_BYPOSITION | (bOn?MF_ENABLED:MF_DISABLED| MF_GRAYED);
	::EnableMenuItem (m_hMenu, m_nIndex, flags);
							  
}

void CMenuItem::SetCheck(BOOL bOn) 
{
	UINT flags;
	flags = MF_BYPOSITION | (bOn?MF_CHECKED:MF_UNCHECKED);
	::CheckMenuItem (m_hMenu, m_nIndex, flags);
}

void CMenuItem::SetRadio(BOOL bOn, UINT nFirst, UINT nLast)
{
	UINT flags;
	if (nFirst < 0) nFirst = m_nIndex;
	if (nLast < 0) nLast = m_nIndex;
	
	flags = MF_BYPOSITION | (bOn?MF_CHECKED:MF_CHECKED);
	::CheckMenuRadioItem (m_hMenu, nFirst, nLast, m_nIndex,
		flags);
}

void CMenuItem::SetText(LPCTSTR lpszText)
{
	MENUITEMINFO mi;
	::GetMenuItemInfo (m_hMenu, m_nIndex, TRUE, &mi);
	mi.fType |= MFT_STRING;
	mi.dwTypeData = (LPTSTR)lpszText;
	::SetMenuItemInfo (m_hMenu, m_nIndex, TRUE, &mi);
}
