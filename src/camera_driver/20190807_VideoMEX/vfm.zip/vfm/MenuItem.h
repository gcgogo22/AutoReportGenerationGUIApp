//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//	MenuItem.h
//		Interface for the CMenuItem class. This class is
//		responsible for abstracting functionality on
//		a menu item. 
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour
//	Revision
//		1998/12/16
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


#if !defined(AFX_MENUITEM_H__F18B4984_8D16_11D2_B14B_0000B482A708__INCLUDED_)
#define AFX_MENUITEM_H__F18B4984_8D16_11D2_B14B_0000B482A708__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMenuItem  
{
public:
	UINT	m_nIndex;	// index of this item
	UINT	m_nId;		// id of this item
	HMENU	m_hMenu;	// main menu
	
	CMenuItem();
	virtual ~CMenuItem();

	virtual void Enable		(BOOL bOn = TRUE);
	virtual void SetCheck	(BOOL bOn = TRUE); 
	virtual void SetRadio	(BOOL bOn = TRUE, UINT nFirst = -1, UINT nLast = -1);
	virtual void SetText	(LPCTSTR lpszText);
};

#endif // !defined(AFX_MENUITEM_H__F18B4984_8D16_11D2_B14B_0000B482A708__INCLUDED_)
