//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// main.cpp
//	Implements the high level code for the Video For Matlab
//	Module.
//	Copyright 
//		(c) 1998 School of Information Systems.
//	Author
//		Farzad Pezeshkpour ( recompiled by Eric Pfeiffer )
//	Revision
//		1998/12/16
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#include "stdafx.h"
#include <string>
#include <strstream>
#include "mex.h"
#include "utility.h"
#include "CaptureFrame.h"


//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// Types
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
typedef void (*Handler) (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);

typedef struct {
	char		*pCommand;
	Handler		 pHandler;
} CommandHandler;


//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//  Forward Declarations
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
bool	ArrayToString			(const mxArray *pArray, std::string &str);
void	CreateFrameWindow		();
void	DestroyFrameWindow		();
void	AssertFrame				();
void	ThrowString				(char * szError);
void	CommandDispatch	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnGrab			(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnShow			(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnConfigSource	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnConfigFormat	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnConfigDisplay	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnPreview		(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnGetDriver		(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void	OnSetDriver		(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
// ------------------------
// Globals
// ------------------------

CCaptureFrame	*pFrame = NULL;
CComModule		_Module; // need one of these in order to use ATL
bool			bFirstTime = true;

CommandHandler	commands[] = {
	"grab",	OnGrab,
	"show", OnShow,
	"configsource", OnConfigSource,
	"configformat", OnConfigFormat,
	"configdisplay", OnConfigDisplay,
	"preview",	OnPreview,
	"drivername", OnGetDriver,
	"setdriver", OnSetDriver
};

void	CreateFrameWindow		() {
	RECT r = {1, 1, 320, 240};
	pFrame = new CCaptureFrame ();
	if (pFrame != NULL)
		pFrame->Create (GetDesktopWindow(), r, "SYS Video For Matlab", WS_OVERLAPPEDWINDOW|WS_VISIBLE);
}

void DestroyFrameWindow () {
	delete_ptr (pFrame);
}

bool	ArrayToString (const mxArray *pArray, std::string &str)
{
	bool okay = true;
	int buflen;
	int status;

	if (mxIsChar(pArray) != 1) {
		str = "vfm: requires a string";
		okay = false;
	}

	buflen = mxGetN(pArray) + 1;
	char *pStr = (char*)mxCalloc (buflen, sizeof(char));
	status = mxGetString (pArray, pStr, buflen);
	if (status != 0)
		mexWarnMsgTxt ("Not enough space. String truncated.");

	str = pStr;
	mxFree(pStr);
	return okay;
}



void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
				 )
{
	if (bFirstTime) {
		CreateFrameWindow();
		mexAtExit(DestroyFrameWindow);
		bFirstTime = false;
	}

	if (nrhs == 0)
		return;
		//mexErrMsgTxt ("vfm: sub command as parameter required");


	try {
		CommandDispatch (nlhs, plhs, nrhs, prhs);
	}

	catch (std::string *pStr) {
		mexWarnMsgTxt(pStr->c_str());
		delete_ptr (pStr);
	}

	return;
}	



//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// DLL Entry Point
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

BOOL APIENTRY DllMain(HANDLE hModule, 
					  DWORD  ul_reason_for_call, 
					  LPVOID lpReserved){
	switch( ul_reason_for_call ) {
	case DLL_PROCESS_ATTACH:
		_Module.Init (NULL, (HINSTANCE)hModule);
		break;
	case DLL_THREAD_ATTACH:    
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		_Module.Term();
		break;
	}    
	return TRUE;
}


void	CommandDispatch	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	std::string str;

	if (!ArrayToString (prhs[0], str)) {
		mexWarnMsgTxt (str.c_str());
		return;
	}
	if (nlhs == 0) nlhs++;
	WORD wItems = sizeof (commands) / sizeof(CommandHandler);
	bool bFound = false;

	for (WORD wIndex = 0; wIndex < wItems && !bFound; wIndex++)
	{
		if (str == commands[wIndex].pCommand) {
			bFound = true;
			commands[wIndex].pHandler(nlhs, plhs, nrhs-1, prhs+1);
		}
	}

	std::ostrstream		error;

	if (!bFound) {
		error << "Unrecognised command: " << str.data() << std::ends;
		ThrowString (error.str());
	}
}


inline void	AssertFrame					()
{
	if (pFrame == NULL) {
		ThrowString ("Capture window does not exist!");
	}
}

inline void	ThrowString				(char * szError)
{
	std::string *pError = new std::string (szError);
	throw (pError);
}

void	OnGrab	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AssertFrame();

	// error checking for arguments
	if (nrhs > 1) {
		ThrowString ("wrong # of arguments - should be 'grab' ?frames?");
	}

	DWORD frames = nlhs;
	if (nrhs == 1) {
		frames = (WORD)mxGetScalar (prhs[0]);
		if (frames == 0) 
			frames = nlhs;
	}

	pFrame->Grab (frames);
	pFrame->GetMatlabArrays(0, frames-1, plhs, nlhs);
}



void	OnShow			(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	bool bShow = true;
	if (nrhs > 1) {
		ThrowString ("wrong # of arguments - should be 'show' ?boolean?");
	}
	if (nrhs == 1) {
		bShow = (mxGetScalar (prhs[0]) != 0);
	}
	pFrame->OnShow (bShow);
}

void	OnConfigSource	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs > 0) {
		ThrowString ("wrong # of arguments - should be 'configsource'");
	}
	if (!pFrame->ConfigureSource ()) {
		ThrowString ("device does not support the Source Configuration dialog.");
	}
}


void	OnConfigFormat (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs > 0) {
		ThrowString ("wrong # of arguments - should be 'configformat'");
	}
	if (!pFrame->ConfigureFormat ()) {
		ThrowString ("device does not support the Format Configuration dialog.");
	}
}

void	OnConfigDisplay	(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs > 0) {
		ThrowString ("wrong # of arguments - should be 'configdisplay'");
	}
	if (!pFrame->ConfigureDisplay ()) {
		ThrowString ("device does not support the Display Configuration dialog.");
	}
}

void OnPreview (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	bool bPreview = true;
	if (nrhs > 1) {
		ThrowString ("wrong # of arguments - should be 'preview' ?boolean?");
	}
	if (nrhs == 1) {
		bPreview = (mxGetScalar(prhs[0]) != 0);
	}
	pFrame->SetPreview (bPreview);
}

void OnGetDriver (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs != 1) {
		ThrowString ("wrong ' of arguments - should be 'drivername' index");
	}
	int index = mxGetScalar(prhs[0]);
	if (index < 1 || index > 10) {
		ThrowString ("index must be in the range 1-10");
	}
	index--;

	std::string *pString = pFrame->GetDriverList ();
	if (pString[index].empty ())
		return;
	const char * szStr = pString[index].c_str();
	plhs[0] = mxCreateString (szStr);
}

void OnSetDriver (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs != 1) {
		ThrowString ("wrong # of arguments - should be 'setdriver' index");
	}
	int index = mxGetScalar(prhs[0]) - 1;
	if (index < 1 || index > 10) {
		ThrowString ("index must be in the range 1-10");
	}

	if (!pFrame->SetDriver ((DWORD)index-1)) {
		ThrowString ("driver does not exist.");
	}
}
