//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDR_MENU1                       101
#define IDR_ACCELERATOR1                102
#define IDI_ICON1                       103
#define IDI_ICON2                       104
#define ID_CONFIGMENU_FORMAT            40001
#define ID_CONFIGMENU_SOURCE            40002
#define ID_CONFIGMENU_DISPLAY           40003
#define ID_WINDOWMENU_PREVIEW           40004
#define ID_WINDOWMENU_RESET             40005
#define ID_WINDOWMENU_STRETCH           40006
#define ID_DEVICEMENU_0                 40007
#define ID_DEVICEMENU_1                 40008
#define ID_DEVICEMENU_2                 40009
#define ID_DEVICEMENU_3                 40010
#define ID_DEVICEMENU_4                 40011
#define ID_DEVICEMENU_5                 40012
#define ID_DEVICEMENU_6                 40013
#define ID_DEVICEMENU_7                 40014
#define ID_DEVICEMENU_8                 40015
#define ID_DEVICEMENU_9                 40016
#define ID_MENUITEM40017                40017
#define ID_WINDOWMENU_HIDE              40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
