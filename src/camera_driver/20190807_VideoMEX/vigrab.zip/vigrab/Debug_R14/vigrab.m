function varargout = ocvgrab(varargin)
% OCVGRAB Perform frame grabbing from any Video for Windows source
%   
% GENERAL SYNTAX: vigrab ( ID-vector, LowResolution, SettingsOn, Synchron ) 
%   
% Grab from one camera:
%   
%   image0 = ocvgrab(0)
%   
%   Grabs the last available image from Camera ID 0. Returns 480 x 640 x 3 array 
%   of double in RGB format.
%   
% Grab from two cameras:
%   
%   [image0 image1] = vigrab([0 1])
%   
%   Grabs the last available images from Camera ID 0 and 1. Returns two arrays 
%   size 480 x 640 x 3 of double in RGB format.
%   
% Grab with lower resolution:
%   
%   [image0 image1] = vigrab([0 1],1)
%   
%   Grabs the last available images from Camera ID 0 and 1. Returns two arrays 
%   size 240 x 320 x 3 of double in RGB format.
%   
% Grab and open camera setup page:
%   
%   [image0 image1] = vigrab([0 1],0,1)
%   
%   Grabs the last available images from Camera ID 0 and 1. Returns two arrays 
%   size 480 x 640 x 3 of double in RGB format and opens two setup windows.
%   !!! Use only with care. !!!
%   
% Grab synchronously:
%   
%   [image0 image1] = vigrab([0 1],0,0,1)
%   
%   Wait for two new images and grab them from Camera ID 0 and 1. Returns two 
%   arrays size 480 x 640 x 3 of double in RGB format.
%   
%   Eric Pfeiffer, 
%       HTWK Leipzig,
%           University of Applied Sciences
%               Revision: 0.0   Date: 2009/07/29
error('Missing MEX-file vigrab.dll');