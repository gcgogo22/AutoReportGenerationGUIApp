/*=================================================================
 *
 * VIGRAB version
 *
 *=================================================================*/
/* $Revision: 0.00 $ */
#include "mex.h"

#include "videoinput.h"

#include <stdio.h>
#include <windows.h>
#include <process.h>

#ifdef R14 // 'R14 - hack'
typedef int mwSize;
#endif

static unsigned LowRes = false;
static unsigned Settings = false;
static unsigned Synchron = false;
static unsigned CamN = 0;
static unsigned CamID[] = {0,0,0,0,0,0,0,0};
static videoInput VI;

// pointer to image-arrays in workspace
mxArray* mImage[] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
struct DIM { 
	int dims[3];
} DIMS[]={{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0}};

/* function closes/destroys all threads, windows and arrays...*/
static void CloseStream(void)
{
	for (unsigned i=0; i<CamN; i++) {
		mexPrintf("Closing CamID %d ...\n",CamID[i]);mexEvalString("disp('');");
		VI.stopDevice(CamID[i]);
		mxDestroyArray(mImage[i]);
		mImage[i] = NULL;
	}
	if (CamN>0) {mexPrintf("finished\n");mexEvalString("disp('');");}
}

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{ 
		/* Check for proper number of arguments */
		if (nrhs==0)
			mexErrMsgTxt("at least one camera identifier necessary e.g. vigrab(0)"); 
		if ((nrhs>0)&&!mxIsDouble(prhs[0]))
			mexErrMsgTxt("camera identifier is double type vector e.g. vigrab([0 1])"); 
		if ((nrhs>1)&&!mxIsDouble(prhs[1]))
			mexErrMsgTxt("camera lowres switch is double type e.g. vigrab([0 1],1)"); 
		if ((nrhs>2)&&!mxIsDouble(prhs[2]))
			mexErrMsgTxt("camera settings switch is double type e.g. vigrab([0 1],0,1)"); 
		if ((nrhs>3)&&!mxIsDouble(prhs[3]))
			mexErrMsgTxt("camera synchron switch is double type e.g. vigrab([0 1],0,0,1)"); 
		unsigned N = min(max((unsigned)mxGetNumberOfElements(prhs[0]),1),8);
		double *cams = (double *)mxGetPr(prhs[0]);

		bool Change = (CamN!=N);
		for (unsigned i=0; i<N; i++) Change |= (CamID[i]!=(unsigned)*(cams+i));
		if (nrhs>1) Change |= (LowRes!=(unsigned)mxGetScalar(prhs[1]));
		if (nrhs>2) Change |= (Settings!=(unsigned)mxGetScalar(prhs[2]));
		if ((nrhs>3)&&(CamN>0)&&(Synchron!=(unsigned)mxGetScalar(prhs[3])))
			mexErrMsgTxt("change in synchron-mode needs a 'clear vigrab' from command line...");

		/* if first start or something is changed - restart all... */
		if ( Change ) { 

			if (CamN>0) { mexPrintf("configuration changed..."); mexEvalString("disp('');"); }
			CloseStream(); 

			if (nrhs>1) LowRes=(unsigned)mxGetScalar(prhs[1]);
			if (nrhs>2) Settings=(unsigned)mxGetScalar(prhs[2]);
			if (nrhs>3) Synchron=(unsigned)mxGetScalar(prhs[3]);
			CamN = N;
			nlhs = N;
			Change = false;

			/* setup videoinput object */
			VI.setVerbose(false);
			VI.setUseCallback(Synchron);
			unsigned numDevices = VI.listDevices();
			mexPrintf("found %d CamIDs...\n",numDevices); mexEvalString("disp('');");

			/* start each camera device and check for proper indication */ 
			for (unsigned i=0; i<CamN; i++) {
				CamID[i]=(unsigned)*(cams+i);
				if (CamID[i]>numDevices-1) mexErrMsgTxt("ID out of range");
				mexPrintf("Connecting CamID %d ...\n",CamID[i]);mexEvalString("disp('');");

				VI.setIdealFramerate(CamID[i],60);
				if ( !VI.setupDevice(CamID[i], (LowRes)?320:640, (LowRes)?240:480)) {
					mexPrintf("CamID %d not ready...\n",CamID[i]);mexEvalString("disp('');");
					CloseStream(); // if something went wrong - stop the threads
					break;
				}
				if (Settings) VI.showSettingsWindow(CamID[i]);

				/* Set Dimension for mex array */
				DIMS[i].dims[0] = VI.getWidth(CamID[i]);
				DIMS[i].dims[1] = VI.getHeight(CamID[i]);
				DIMS[i].dims[2] = 3;

				/* Create the picture matrix for the return argument (if changed or not yet existing)*/
				mImage[i] = mxCreateNumericArray(3,(const mwSize*)DIMS[i].dims, mxUINT8_CLASS, mxREAL); 
				if (!mImage[i]) mexErrMsgTxt("could not create array in workspace...");
				mexMakeArrayPersistent(mImage[i]);
			}
		}

		for (unsigned i=0; i<CamN; i++) {

			/* Copy image to matlab */
			if ( Synchron || VI.isFrameNew(CamID[i]) ) 
				VI.getPixels(CamID[i], (unsigned char*)mxGetPr(mImage[i]), false, false);

			plhs[i] = mImage[i];

		}
        
        mexAtExit(CloseStream);

        return;
}